package talleravaluable1;

import java.io.*;

// Classe per gestionar l'entrada i sortida d'objectes dels fitxers
public class FitxerPartidaIN {

    FileInputStream sortida;
    ObjectInputStream ois;

    // Constructor per inicialitzar el fitxerPartidaIN amb el nom del fitxer introduit per paràmetre
    public FitxerPartidaIN(String nomFitxer) {
        try {
            sortida = new FileInputStream(nomFitxer);
            ois = new ObjectInputStream(sortida);

        } catch (Exception ex) {
            System.out.println(ex);
        }

    }

    // Métode que llegeix el fitxer de les partides i retorna els jugadors emmagatzemats
    public JugadorPartida[] llegeixPartides() {
        JugadorPartida[] jugadors = null;
        try {

            int objectes = contarObjectes();
            
            // Tornam a obrir el fileInputStream i l'ObjectInputStream
            sortida = new FileInputStream("Partidas.txt");
            ois = new ObjectInputStream(sortida);
            
             //Declaram l'array amb el nombre d'espais igual al nombre d'objectes que hi ha al fitxer
            jugadors = new JugadorPartida[objectes];

            JugadorPartida jp = (JugadorPartida) ois.readObject(); // Llegim el primer objecte
            for (int i = 0; i < jugadors.length; i++) {
                jugadors[i] = jp; //Anam omplint l'array de jugadors amb el noms que anam llegint
                jp = (JugadorPartida) ois.readObject(); //Seguim llegint els objectes
            }
            ois.close();
            sortida.close();

        } catch (Exception ex) {
            System.out.println(ex);
        }

        return jugadors;

    }


    // Métode per tancar els fitxers de forma encapsulada
    public void tancar() {
        try {
            ois.close();
            sortida.close();

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    public int contarObjectes(){
        int objectes=0;
        try{
            
        JugadorPartida pt=(JugadorPartida)ois.readObject();
            while(!pt.esCentinela()){
                objectes++;
                pt=(JugadorPartida)ois.readObject();
            }
            ois.close();
            sortida.close();
        }catch(Exception ex){
            System.out.println(ex);
        }
        return objectes;
    }
}
