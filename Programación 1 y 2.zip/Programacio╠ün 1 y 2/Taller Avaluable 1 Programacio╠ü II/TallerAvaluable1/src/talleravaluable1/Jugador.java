package talleravaluable1;

import java.io.*;
import java.util.Random;

// Classe jugador d'on anirem treient les dades pertinents
public class Jugador implements Serializable {

    private String nomJugador;
    private int minutsJugats;
    private int victoriesAtacant;
    private int victoriesDefensor;
    private static final int MAXIM_JUGADORS = 10;
    private static final int TOTAL_JUGADORS = 510;
    private static final int MAXIM_NOM = 20;

    

    public static int getMAXIM_JUGADORS() {
        return MAXIM_JUGADORS;
    }

    public static int getTOTAL_JUGADORS() {
        return TOTAL_JUGADORS;
    }

    public void setMinutsJugats(int minutsJugats) {
        this.minutsJugats = minutsJugats;
    }

    public void setVictoriesAtacant(int victoriesAtacant) {
        this.victoriesAtacant = victoriesAtacant;
    }

    public void setVictoriesDefensor(int victoriesDefensor) {
        this.victoriesDefensor = victoriesDefensor;
    }

    public String toString() {

        String s = "";
        s = "Jugador: " + this.nomJugador + "\t/Temps jugat: " + this.minutsJugats
                + " /Victories com atacant: " + this.victoriesAtacant
                + " /Victories com a defensor: " + this.victoriesDefensor;
        return s;

    }

    
    public static int getMAXIM_NOM() {
        return MAXIM_NOM;
    }

}
