package talleravaluable1;

import java.io.*;

public class Main {

    public static void main(String[] args) {
        new Main().menu();

    }

    private static void menuJoc() {
        System.out.println("\n\nGESTIÓ DE JOC");
        System.out.println("\n\t1. Inicialitza fitxers jugadors ");
        System.out.println("\t2. Genera partida");
        System.out.println("\t3. Actualitza jugadors amb la partida actual");
        System.out.println("\t0. Sortir");
    }

    private void menu() {
        char opcio = 'Z';
        do {
            menuJoc();

            opcio = llegirCaracter("Quina opció vols escollir? ");
            switch (opcio) {
                case '1':
                    // Creació del fitxer amb 10 jugadors elegirs al atzar
                    FitxerJugadors fj = new FitxerJugadors();
                    String[] noms = fj.llegirNomJugador("LlistaNoms.txt"); //Llegim els noms del fitxer proporcionat pel professor
                    fj.nousJugadors(noms);
                    System.out.println(fj);
                    break;
                    
                case '2':
                    // Es crea una partida aleatoria
                    JugadorPartida.partidaAleatoria();
                    break;
                    
                case '3':
                    // Actualització dels jugadors amb la partida actual
                    FitxerJugadors fj2 = new FitxerJugadors();
                    fj2.actualitza(); //Feim l'actualització de les dades del jugador al fitxer
                    System.out.println(fj2);
                    break;
                    
                case '0':
                    break;
                default:
                    System.out.println("Opció incorrecta. Torna a intentar-ho!!");
                    break;
            }
        } while (opcio != '0');
        System.out.println("Fins un altre!!!");
    }

    // Métode del professor per poder llegir un caràcter per pantalla
    // S'introdueix el missatge que vols que s'imprimeixi per pantalla com a paràmetre
    private char llegirCaracter(String missatge) {
        char c = ' ';
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(missatge);
            // Llegim un String
            String s = in.readLine();
            char d[] = s.toCharArray();
            c = d[0];

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return c;

    }

}
