package talleravaluable1;

import java.io.*;

//Classe per dur a terme l'escriptura amb objectes als fitxers 

public class FitxerPartidaOUT {

    FileOutputStream sortida;
    ObjectOutputStream oos;

    // Constructor per inicialitzar el FitxerPartidaOUT amb el nom del fitxer introduit per paràmetre
    public FitxerPartidaOUT(String nomFitxer) {
        try {
            sortida = new FileOutputStream(nomFitxer);
            oos = new ObjectOutputStream(sortida);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    // Métode per escriure als fitxers de forma encapsulada
    public void escriureJugadorPartida(JugadorPartida jp) {
        try {
            oos.writeObject(jp);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    

    // Métode per tancar els fitxers de forma encapsulada
    public void tancar() {
        try {
            oos.close();
            sortida.close();

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

}
