package talleravaluable1;

import java.io.*;
import java.util.Random;
import static talleravaluable1.Jugador.getMAXIM_NOM;

// Classe on utilitzarem les funcions del RandomAccessFile per actualitzar fitxers
public class FitxerJugadors {

    private static final int MIDAREG = (Jugador.getMAXIM_NOM() * 2) + 12;
    private static File arxiu = new File("Jugadors.txt");
    private RandomAccessFile f;

    public FitxerJugadors() {
        try {
            f = new RandomAccessFile(arxiu, "rw");
            f.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }

    }

    public String toString() {
        String s = "";
        try {

            f = new RandomAccessFile(arxiu, "r");
            long numreg = f.length() / MIDAREG;

            for (int r = 0; r < numreg; r++) {
                String nom = "";
                for (int i = 0; i < Jugador.getMAXIM_NOM(); i++) {
                    nom += f.readChar();
                }
                int minutsJugats = f.readInt();
                int victoriesAtacant = f.readInt();
                int victoriesDefensor = f.readInt();

                s += "\nJugador: " + nom + "\t/Temps jugat: " + minutsJugats
                        + " /Victories com atacant: " + victoriesAtacant
                        + " /Victories com a defensor: " + victoriesDefensor;
            }
            f.close();
        } catch (Exception e) {
        } finally {
            arxiu.deleteOnExit();
        }
        return s;
    }

    public String[] llegirNomJugador(String nomFitxer) {
        //String de 10 posiciones per emmagatzemar els jugadors
        String[] jugadors = new String[Jugador.getMAXIM_JUGADORS()];

        Random randy = new Random();

        try {

            //Omplim l'array dels jugadors de forma aleatoria
            for (int i = 0; i < jugadors.length; i++) {
                FileReader fr = new FileReader(nomFitxer);
                BufferedReader br = new BufferedReader(fr);
                int posicioRandy = randy.nextInt(Jugador.getTOTAL_JUGADORS()); //Random entre 0 i 509
                // Feim el recorregut del fitxer fins arribar al jugador que ha sortit en la posició del randy
                for (int j = 0; j < posicioRandy; j++) {
                    jugadors[i] = br.readLine();
                }
                br.close();
                fr.close();
            }

        } catch (Exception ex) {
        }
        return jugadors;

    }

    // Métode que du a terme l'escriptura dels jugadors al fitxer
    public void nousJugadors(String[] noms) {

        try {

            f = new RandomAccessFile(arxiu, "rw"); // arxiu de jugadors

            for (int i = 0; i < noms.length; i++) {
                while (noms[i].length() < 20) {
                    noms[i] += " "; //Tots els noms ocupen 20 espais
                }

                // Escrivim les dades dels jugadors al fitxer:
                f.writeChars(noms[i]); // El nom
                f.writeInt(0); // Els minuts jugats
                f.writeInt(0); // Victories com atacant
                f.writeInt(0); // Victories com a defensor

            }
            f.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            arxiu.deleteOnExit();
        }
    }

    //
    public void actualitza() {
        FitxerPartidaIN fpi = new FitxerPartidaIN("Partidas.txt");
        JugadorPartida[] jp = fpi.llegeixPartides();

        try {
            f = new RandomAccessFile(arxiu, "rw"); // arxiu de jugadors

            // Recorregut de tots els jugadors per anar actualitzant les seves estadístiques de partida
            for (int i = 0; i < jp.length; i++) {

                int codi = jp[i].getCodi();
                boolean victoria = jp[i].isVictoria();
                boolean rol = jp[i].isRol();

                // Ens posicionam amb el filePointer damunt el temps
                f.seek(codi * MIDAREG + getMAXIM_NOM() * 2); // Això bota el nom del jugador
                int temps = f.readInt() + 10; //Li agregam 10 minuts de la partida jugada
                f.seek(codi * MIDAREG + getMAXIM_NOM() * 2); //Ens tornam a posicionar damunt el temps
                f.writeInt(temps); // Escrivim el temps actualitzat

                // Si el jugador guanya la partida...
                if (victoria) {
                    int victories = f.readInt();
                    // Miram si es atacant o defensor
                    if (!rol) {
                        victories = f.readInt(); //En cas de que sigui defensor, ens botarem les victories d'atac
                    }
                    
                    f.seek(codi * MIDAREG + getMAXIM_NOM() * 2 + 4);

                    if (!rol) { 
                        f.readInt(); // Si ha guanyat com a defensor avançarem el punter cap a les dades de victories defensor
                    }

                    f.writeInt(victories + 1); // Sumam una victoria als que han guanyat la partida en la posició adient

                }
            }
            f.close();

        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }

    }
}
