package talleravaluable1;

import java.io.*;
import java.util.Random;

// Classe per gestionar el fitxer on guardarem els jugadors de cada partida
public class JugadorPartida implements Serializable {

    private int codi;
    private boolean victoria;
    private boolean rol;
    public final static JugadorPartida CENTINELA = new JugadorPartida(999, true, true);

    public JugadorPartida(int codi, boolean victoria, boolean rol) {
        this.codi = codi;
        this.victoria = victoria;
        this.rol = rol;

    }

    public int getCodi() {
        return codi;
    }

    public boolean isVictoria() {
        return victoria;
    }

    public boolean isRol() {
        return rol;
    }

    // Métode per iniciar una partida aleatoria del joc
    public static void partidaAleatoria() {
        // Obrim el fitxer on escriurem les partides
        FitxerPartidaOUT fpout = new FitxerPartidaOUT("Partidas.txt");
        int nombreAleatori;
        Random randy = new Random();
        nombreAleatori = randy.nextInt(4) + 2; // Generarem un nombre aleatori entre 2 i 5
        for (int i = 0; i < nombreAleatori; i++) {
            // També de forma aleatoria generarem un jugador entre 0 i 9
            JugadorPartida jp = new JugadorPartida(randy.nextInt(10), randy.nextBoolean(), randy.nextBoolean());
            System.out.println(jp);
            fpout.escriureJugadorPartida(jp);
        }
        // Al final de tots els jugadors escriurem l'objecte centinela
        fpout.escriureJugadorPartida(CENTINELA);
        fpout.tancar();
    }

    public boolean esCentinela() {
        return this.codi == CENTINELA.codi;

    }

    public String toString() {
        String s = "Defensor";
        if (rol) {
            s = "Atacant";
        }
        return "JugadorPartida " + this.codi + ", Victoria = " + this.victoria + ", rol = " + s;

    }

}
