/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rolbuades;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;


/**
 *
 * @author maribelcrespivalero
 */
public class FicheroDireccionesOut {
    
    private FileOutputStream fis;
    private ObjectOutputStream ois;
    
    public FicheroDireccionesOut(String nomFitxer){
        try{
            fis= new FileOutputStream(nomFitxer);
            ois= new ObjectOutputStream(fis);
            
        }catch(IOException ex){
            System.out.println(ex);
        }
    }
    
    public void escriure(Personaje p){
        try{
            ois.writeObject(p);
        }catch(IOException ex){
            
        }
    }
    
    public void tancar(){
        try{
            ois.close();
            fis.close();
        }catch(IOException ex){
            
        }
    }
}
