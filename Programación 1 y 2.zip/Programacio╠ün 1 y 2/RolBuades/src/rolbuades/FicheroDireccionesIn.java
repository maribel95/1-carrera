/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rolbuades;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author maribelcrespivalero
 */
public class FicheroDireccionesIn {
    private FileInputStream fis;
    private ObjectInputStream ois;
    
    public FicheroDireccionesIn(String nomFitxer){
        try{
            fis= new FileInputStream(nomFitxer);
            ois= new ObjectInputStream(fis);
            
        }catch(IOException ex){
            System.out.println(ex);
        }
    }
    public Personaje leerDireccion() {
        Personaje p=null;
        try{
            
            p=(Personaje)ois.readObject();
            
        }catch(IOException | ClassNotFoundException ex){
            System.out.println(ex);
        }
        return p;
    }
    
    public boolean finalDeFichero(){
        int x=0;
        try{
           x=(int)ois.readObject();
           
        }catch(IOException ex){
            System.out.println(ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FicheroDireccionesIn.class.getName()).log(Level.SEVERE, null, ex);
        }
        return x==-1;
    }
    
    public void tancar(){
        try{
            ois.close();
            fis.close();
        }catch(IOException ex){
            
        }
    }
}
