/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rolbuades;

import java.io.Serializable;

/*
a) Realizar un pequeño interfaz donde el usuario da órdenes a un personaje, y en un fichero debe escribir sus movimientos.
Inicialmente el personaje está en un mundo en la coordenada (0, 0) mirando hacia arriba (que sería la casilla (0,1))
El usuario tiene las siguientes operaciones:
• Avanzar. Avanza una casilla en la dirección que mira.
• Saltar. Avanza dos casillas en la dirección que mira
• Girar derecha. No cambio su posición, sólo la dirección en la que mira. Si estaba
mirando hacia arriba, pasa a mirar a la derecha. Si estaba mirando a la derecha, pasa a
mirar hacia abajo.
• Girar izquierda. No cambia su posición, sólo cambia la dirección a la que mira. Por
ejemplo, si miraba hacia la izquierda, pasa a mirar hacia abajo (ver figura). 
Si mira hacia abajo, y gira a la izquierda, pasa a mirar a la derecha.
·Media vuelta. Si miraba a la izquierda, pasa a mirar a la derecha, y viceversa. 

Si miraba hacia arriba pasa a mirar hacia abajo y viceversa.
El programa debe ir pidiendo al usuario las acciones, y debe ir guardando en un 
fichero las coordenadas por las que pasa, eso implica que los giros no generan nada en el fichero.


 */
public class Personaje implements Serializable{

    private int coordenadaX;
    private int coordenadaY;
    private Direccion direccion;
    public final static Personaje CENTINELA= new Personaje(999,999,Direccion.ARRIBA);

    public Personaje() {
        this.coordenadaX = 0;
        this.coordenadaY = 0;
        this.direccion = Direccion.ARRIBA;
    }
    public Personaje(int x, int y, Direccion dir) {
        this.coordenadaX = x;
        this.coordenadaY = y;
        this.direccion = dir;
    }

    public void avanzar() {
        switch (this.direccion) {
            case ARRIBA:
                this.coordenadaY++;
                break;
            case ABAJO:
                this.coordenadaY--;
                break;
            case IZQUIERDA:
                this.coordenadaX--;
                break;
            case DERECHA:
                this.coordenadaX++;
                break;
        }
        FicheroDireccionesOut fichero= new FicheroDireccionesOut("Coordenadas.dat");
        fichero.escriure(this);
        fichero.tancar();
    }

    public void saltar() {
        switch (this.direccion) {
            case ARRIBA:
                this.coordenadaY++;
                this.coordenadaY++;
                break;
            case ABAJO:
                this.coordenadaY--;
                this.coordenadaY--;
                break;
            case IZQUIERDA:
                this.coordenadaX--;
                this.coordenadaX--;
                break;
            case DERECHA:
                this.coordenadaX++;
                this.coordenadaX++;
                break;
        }
        FicheroDireccionesOut fichero= new FicheroDireccionesOut("Coordenadas.dat");
        fichero.escriure(this);
        fichero.tancar();
    }

    public void girarDerecha() {
        switch (this.direccion) {
            case ARRIBA:
                this.direccion=Direccion.DERECHA;
                break;
            case ABAJO:
                this.direccion=Direccion.IZQUIERDA;
                break;
            case IZQUIERDA:
                this.direccion=Direccion.ARRIBA;
                break;
            case DERECHA:
                this.direccion=Direccion.ABAJO;
                break;
        }
    }

    public void girarIzquierda() {
        switch (this.direccion) {
            case ARRIBA:
                this.direccion=Direccion.IZQUIERDA;
                break;
            case ABAJO:
                this.direccion=Direccion.DERECHA;
                break;
            case IZQUIERDA:
                this.direccion=Direccion.ABAJO;
                break;
            case DERECHA:
                this.direccion=Direccion.ARRIBA;
                break;
        }
    }

    public void mediaVuelta() {
        switch (this.direccion) {
            case ARRIBA:
                this.direccion=Direccion.ABAJO;
                break;
            case ABAJO:
                this.direccion=Direccion.ARRIBA;
                break;
            case IZQUIERDA:
                this.direccion=Direccion.DERECHA;
                break;
            case DERECHA:
                this.direccion=Direccion.IZQUIERDA;
                break;
        }
    }
    
    public boolean esCentinela(){
        return (this.coordenadaX==CENTINELA.coordenadaX) && (this.coordenadaY==CENTINELA.coordenadaY);
    }

    

    @Override
    public String toString() {
        return "(" + coordenadaX + ", " + coordenadaY + ")\n";
    }
    

}
