/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rolbuades;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author maribelcrespivalero
 */
public class RolBuades {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new RolBuades().menu();
    }

    private static void menuJuego() {
        System.out.println("\n\nGESTIÓN DEL JUEGO");
        System.out.println("\n\t1. AVANZAR ");
        System.out.println("\t2. SALTAR");
        System.out.println("\t3. GIRAR DERECHA");
        System.out.println("\t4. GIRAR IZQUIERDA");
        System.out.println("\t5. MEDIA VUELTA");
        System.out.println("\t6. LEER FICHERO DE COORDENADAS");
        System.out.println("\t0. SALIR\n");
    }

    private void menu() {

        Personaje p1 = new Personaje();

        char opcio = 'Z';
        do {
            menuJuego();
            opcio = leerCaracter("Qué opción quieres escoger? \n\n");
            switch (opcio) {
                case '1':
                    p1.avanzar();
                    
                    System.out.println("Estás en la posición: "+p1);

                    break;

                case '2':
                    p1.saltar();
                    System.out.println("Estás en la posición: "+p1);

                    break;

                case '3':
                    p1.girarDerecha();
                    

                    break;
                case '4':
                    p1.girarIzquierda();

                    break;
                case '5':
                    p1.mediaVuelta();

                    break;
                case '6':
                    FicheroDireccionesIn ficheroLectura = new FicheroDireccionesIn("Coordenadas.dat");
                    p1= ficheroLectura.leerDireccion();
                    System.out.println(p1);
                    p1= ficheroLectura.leerDireccion();
                    System.out.println(p1);
                        
                    
                    
                    ficheroLectura.tancar();
                    break;

                case '0':
                   
                    break;
                default:
                    System.out.println("Opción incorrecta. Vuelve a intentarlo!!");
                    break;
            }
        } while (opcio != '0');
        System.out.println("Hasta mañana magdaleno!!!");
    }

    private char leerCaracter(String missatge) {
        char c = ' ';
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(missatge);
            // Llegim un String
            String s = in.readLine();
            char d[] = s.toCharArray();
            c = d[0];

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return c;

    }
}
