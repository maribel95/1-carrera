package p2;

/**
 *
 * @author maribelcrespivalero
 */

//He implementat el problema amb una classe tortuga i crec que encara que
//s'aconsegueix una millor encapsulació, entorpeix molt la llegibilitat del codi
//per part d'un altre programador, i veient el resultat final del programa actual 
//(una clase TaulerTortuga bastant llegible i senzilla), opin que no val la pena
//sacrificar una molt bona llegibilitat en detriment de una lleugera encapsulació.
public class Principal {

    public static void main(String[] args) {
        new Principal().Inicio();
    }
    
    private void Inicio() {
        //Inicialitzam tauler de 20 x 20.
        TaulerTortuga t = new TaulerTortuga(20);
        System.out.println(t);
        
        //Realitzam les accions y anam imprimint el tauler actualitzat cada vegada.
        t.envant(5);
        t.dreta();
        System.out.println(t);
        
        t.envant(5);
        t.dreta();
        System.out.println(t);
        
        t.envant(5);
        t.dreta();
        System.out.println(t);
    }
    
}
