package p2;

import java.util.Random;

/**
 *
 * @author maribelcrespivalero
 */
public class TaulerTortuga {

    //Coordenades actuals de la tortuga
    private int x;
    private int y;

    //Direccio actual de la tortuga
    private Direccio d;
    
    //Tauler per on se mourà la tortuga
    private final char[][] t;

    //Constructor al que li introduim el tamany del costat de la matriu quadrada.
    public TaulerTortuga(int costat) {

        t = new char[costat][costat];

        inicialitzarMon();
        inicialitzarTortuga();
    }
    
    //Colocam '-' a totes les caselles 
    private void inicialitzarMon() {

        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t.length; j++) {

                t[i][j] = '-';
            }
        }
    }

    //Generam una coordenada x,y, y colocarem la tortuga allà. També li
    //assignarem la direcció predeterminada EST.
    private void inicialitzarTortuga() {

        Random rnd = new Random();
        x = rnd.nextInt(t.length);
        y = rnd.nextInt(t.length);
        t[x][y] = 'o';

        d = Direccio.EST;
    }

    @Override
    public String toString() {

        //Si volem imprimir el tauler dues vegades seguides, no volem que l'usuari
        //confongui un tauler amb l'altre, per tant crearem una gran separació.
        String s = "\n\n\n\n";

        //Recorrem totes les caselles del tauler i hi ficam el caràcter
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t.length; j++) {

                s += t[i][j];
            }
            s += "\n";
        }
        return s;
    }

    // Métode que canvia la direcció de la tortuga cap a la dreta.
    public void dreta() {
        switch (d) {
            case EST:

                d = Direccio.SUD;
                break;
            case OEST:

                d = Direccio.NORD;
                break;
            case NORD:

                d = Direccio.EST;
                break;
            case SUD:

                d = Direccio.OEST;
        }
    }

    //Mètode per fer avançar a la tortuga
    //  n = pasos totals a fer
    public void envant(int n) {

        //Sabem que un límit es el 0, però l'altre l'hem de calcular
        int limit = t.length - 1;
        
        //A la posicio inicial de la tortuga hi colocarem ja el rastre. No pasa
        //res si hi avançam 0 posicions: al final hi tornam a colocar la tortuga.
        t[x][y] = '*';
        
        //Segons la direcció que té la tortuga haurem de tenir cura amb el límit
        //del costat del tauler cap al que estem avançant.
        //
        //He decidit agafar la 'y' com a variable horitzontal, i la 'x' per a la vertical.
        switch (d) {
            case EST:
                
                //  Farem un for segons l'enter introduit per paràmetre (pasos totals), on a cada
                //  repetició hi donarem un pas. Un aspecte a destacar es que per a cada repetició
                //  també hi comprovam que la component a modificar no estigui al límit de la
                //  direcció corresponent. Si és així sortim del bucle, encara que no haguem donat
                //  totes les passes. (Aixó per a cada cas).
                for (int i = 0; (i < n) && (y < limit); i++) {

                    //Simulam un pas de la tortuga
                    y++;
                    
                    //Feim que la seva posició actual deixi la estel·la. En cas de ser la seva
                    //posició final, al final del mètode fora del switch li assignarem el
                    //caràcter corresponent.
                    t[x][y] = '*';
                }

                break;
            case OEST:
                
                for (int i = 0; (i < n) && (y > 0); i++) {

                    y--;
                    
                    t[x][y] = '*';
                }
                
                break;
            case NORD:
                
                for (int i = 0; (i < n) && (x > 0); i++) {

                    x--;
                    
                    t[x][y] = '*';
                }

                break;
            case SUD:
                
                for (int i = 0; (i < n) && (x < limit); i++) {

                    x++;
                    
                    t[x][y] = '*';
                }
        }

        //Finalment posam a la posició final el símbol de la tortuga.
        t[x][y] = 'o';
    }


}
