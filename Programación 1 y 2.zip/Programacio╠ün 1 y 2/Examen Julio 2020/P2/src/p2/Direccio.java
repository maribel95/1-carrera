package p2;

/**
 *
 * @author maribelcrespivalero
 */

// Enumeracio de les posibles direccions que pot tenir la tortuga.
public enum Direccio {
    NORD, EST, SUD, OEST
}
