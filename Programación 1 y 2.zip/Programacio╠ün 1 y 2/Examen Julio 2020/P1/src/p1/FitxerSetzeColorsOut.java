package p1;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Random;
/**
 *
 * @author maribelcrespivalero
 */
//Classe per facilitar l'escriptura en fitxers
public class FitxerSetzeColorsOut {

    private FileOutputStream fos;
    private ObjectOutputStream oos;

    public FitxerSetzeColorsOut(String nomFitxer) {
        try {
            
            //Flux de sortida de objectes SetzeColors
            fos = new FileOutputStream(nomFitxer);
            oos = new ObjectOutputStream(fos);
            
            //Segons l'enunciat, al constructor anirem generant i escrivint
            //SetzeColors aleatoris.
            generarColorsAleatoris();
            
            //Tancam el fluxe de sortida aquí mateix
            tancar();
            
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
    
    //Aquest mètode generarà SetzeColors aleatoris fins arribar al color BLACK,
    //que fa de centinela.
    private void generarColorsAleatoris() {

        Random aleatori = new Random();

        //La quantitat total de SetzeColors(16)
        int valorMaxim = SetzeColors.values().length;
        
        //Escollim un índex que servirà per seleccionar el SetzeColor.
        int x = aleatori.nextInt(valorMaxim);

        // Obtenim l'objecte SetzeColor generat aleatoriament
        SetzeColors z = SetzeColors.values()[x];

        // Escriurem SetzeColors fins arribar al Centinela(SetzeColor BLACK)
        while (!z.equals(SetzeColors.BLACK)) {

            //  Escribim el color
            escriureSetzecolor(z);

            //  Generarem un nou nombre i per tant un nou color (serà el seu índex)
            x = aleatori.nextInt(valorMaxim);
            z = SetzeColors.values()[x];
        }

        //Escrivim el centinela BLACK
        escriureSetzecolor(SetzeColors.BLACK);
    }

    private void escriureSetzecolor(SetzeColors sz) {
        try {
            
            oos.writeObject(sz);
            
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    public void tancar() {
        try {
            
            oos.close();
            fos.close();
            
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}
