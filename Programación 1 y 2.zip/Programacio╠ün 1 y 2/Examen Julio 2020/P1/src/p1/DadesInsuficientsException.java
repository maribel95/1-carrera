package p1;
/**
 *
 * @author maribelcrespivalero
 */
public class DadesInsuficientsException extends Exception{
    
    public DadesInsuficientsException() {
        super("No hi ha colors apart del centinela");
    }
    
    public DadesInsuficientsException(String s) {
        super(s);
    }
}
