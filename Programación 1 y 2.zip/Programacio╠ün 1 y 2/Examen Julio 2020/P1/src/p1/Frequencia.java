package p1;

/**
 *
 * @author maribelcrespivalero
 */
public class Frequencia {

    public void ordenaFrequencia(String s) {
        try {

            FitxerSetzeColorsIn fsi = new FitxerSetzeColorsIn("Fitxer SetzeColors.txt");
            int contador = 0;

            SetzeColors sz = (SetzeColors) fsi.llegirColor();
            while (!sz.equals(SetzeColors.BLACK)) {

                contador++;

                //Llegim el següent SetzeColors.
                sz = (SetzeColors) fsi.llegirColor();
            }
            fsi.tancar();

            //
            //Ja sabem quants colors hi ha
            //Ara els ficarem a un array per a ordenar-los
            SetzeColors arrayColors[] = new SetzeColors[contador];

            FitxerSetzeColorsIn fsi2 = new FitxerSetzeColorsIn("Fitxer SetzeColors.txt");
            for (int i = 0; i < contador; i++) {
                arrayColors[i] = (SetzeColors) fsi2.llegirColor();
            }
            fsi2.tancar();

            bombollaMillorada(arrayColors);

        } catch (Exception e) {
            System.out.println(e);
        }

    }

    //Ordenam els colors amb el mètode de la bombolla millorada 
    // segons les seves components.
    private void bombollaMillorada(SetzeColors[] sz) {

        final int N = sz.length;
        SetzeColors x;

        int i = 0;
        while (i < N - 1) {
            int lj = N;
            for (int j = N - 2; j >= i; j--) {

                if (sz[j + 1].esMenor(sz[j])) {

                    //Canviam les posicions només si era menor
                    x = sz[j + 1];
                    sz[j + 1] = sz[j];
                    sz[j] = x;
                    lj = j;
                }

            }
            i = lj + 1;

        }
        imprimirColorsPerPosicio(sz);
    }

    private void imprimirColorsPerPosicio(SetzeColors[] z) {

        System.out.println("Num colors: " + z.length);
        System.out.println("Contingut de la taula de colors anomenats:");

        for (int i = 0; i < z.length; i++) {

            System.out.println(z[i].name() + "   " + z[i].toColor());

        }
    }
}
