package p1;

import java.awt.Color;
/**
 *
 * @author maribelcrespivalero
 */
public class Promig {

    public void calcularPromig() {

        int contadorColors = 0;
        int totalRed = 0;
        int totalGreen = 0;
        int totalBlue = 0;

        try {

            FitxerSetzeColorsIn fsi = new FitxerSetzeColorsIn("Fitxer SetzeColors.txt");

            SetzeColors sz = (SetzeColors) fsi.llegirColor();
            while (!sz.equals(SetzeColors.BLACK)) {

                //Comptam un color més
                contadorColors++;

                //Sumam les components al total de cada color
                totalRed += sz.getRed();
                totalGreen += sz.getGreen();
                totalBlue += sz.getBlue();

                //Llegim el següent SetzeColors.
                sz = (SetzeColors) fsi.llegirColor();
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
        try {
            int finalRed = totalRed / contadorColors;
            int finalGreen = totalGreen / contadorColors;
            int finalBlue = totalBlue / contadorColors;

            Color c = new Color(finalRed, finalGreen, finalBlue);
            System.out.println("Color promig: " + c);
        } catch (Exception ex) {
            System.out.println("DadesInsuficients");
        }
    }
}
