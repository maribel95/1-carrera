package p1;

import java.io.Serializable;
import java.awt.Color;

// Classe donada pel professor serializable 
public enum SetzeColors implements Serializable {
    AQUA(0, 255, 255),
    BLACK(0, 0, 0),
    BLUE(0, 0, 255),
    FUCHSIA(255, 0, 255),
    GRAY(128, 128, 128),
    GREEN(0, 128, 0),
    LIME(0, 255, 0),
    MAROON(128, 0, 0),
    NAVY(0, 0, 128),
    OLIVE(128, 128, 0),
    PURPLE(128, 0, 128),
    RED(255, 0, 0),
    SILVER(192, 192, 192),
    TEAL(0, 128, 128),
    WHITE(255, 255, 255),
    YELLOW(255, 255, 0);

    private final Integer red, green, blue;

    private SetzeColors(final Integer red, final Integer green, final Integer blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    public Integer getRed() {
        return red;
    }

    public Integer getGreen() {
        return green;
    }

    public Integer getBlue() {
        return blue;
    }

    public Color toColor() {
        return new Color(red, green, blue);
    }

    @Override
    public String toString() {
        String s = this.name();
        for (int i = this.name().length(); i < 7; i++) {
            s += " ";
        }
        return s;
    }

    //Métode que retorna true si el color que ha cridat l'objecte "es menor"
    //que el del paràmetre.
    public boolean esMenor(SetzeColors c2) {

        SetzeColors c1 = this;

        if (c1.getRed() != c2.getRed()) {

            if (c1.getRed() < c2.getRed()) {
                return true;
            }
            return false;

        } else if (c1.getGreen() != c2.getGreen()) {

            if (c1.getGreen() < c2.getGreen()) {
                return true;
            }
            return false;
        } else if (c1.getBlue() != c2.getBlue()) {

            if (c1.getBlue() < c2.getBlue()) {
                return true;
            }
        }
        
        //Retornarem false si no hem sortir per cap return: ja sigui perque
        //eren iguals, o perque el segon color era major a la component blau.
        return false;
    }
}
