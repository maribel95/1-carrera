package p1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
/**
 *
 * @author maribelcrespivalero
 */
// Clase per l'entrada de dades de fitxers de colors
public class FitxerSetzeColorsIn {

    private FileInputStream fis;
    private ObjectInputStream ois;

    public FitxerSetzeColorsIn(String nomFitxer) {
        try {

            fis = new FileInputStream(nomFitxer);
            ois = new ObjectInputStream(fis);

        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    public SetzeColors llegirColor() {

        SetzeColors sz = null;

        try {

            sz = (SetzeColors) ois.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex);
        }
        return sz;
    }

    public void tancar() {
        try {

            ois.close();
            fis.close();

        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
    
    // Mètode que mostra el contingut del fitxer (he interpretat que no ha de ser
    //  el mètode toString).
    public void imprimirFitxer() {
        try {
            
            System.out.println("Contingut del fitxer de colors anomenats: ");
            
            SetzeColors sz = (SetzeColors) ois.readObject();
            while (!sz.equals(SetzeColors.BLACK)) {

                //Mostram el color
                System.out.println(sz.name());
                
                //Llegim el següent SetzeColors.
                sz = (SetzeColors) ois.readObject();
            }
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex);
        }


    }
}
