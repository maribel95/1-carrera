package p1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author maribelcrespivalero
 */
public class Principal {

    public static void main(String[] args) {

        new Principal().Inicio();
    }

    private void Inicio() {
        
        boolean repetir = true;

        while (repetir) {

            menu();

            int opcio = llegirEnter("\nInserir opció: ");
            switch (opcio) {
                case 1:
                    //Al constructor generam els SetzeColors aleatoris i els escrivim.
                    //Es tanca al mateix constructor, donat que només l'utilitzam per a això.
                    FitxerSetzeColorsOut fso = new FitxerSetzeColorsOut("Fitxer SetzeColors.txt");
                    
                    //  Imprimirem per pantalla el contingut del fitxer generat.
                    FitxerSetzeColorsIn fsi = new FitxerSetzeColorsIn("Fitxer SetzeColors.txt");
                    fsi.imprimirFitxer();
                    fsi.tancar();
                    break;
                case 2:
                    
                    new Promig().calcularPromig();

                    break;
                case 3:
                    
                    new Frequencia().ordenaFrequencia("Fitxer SetzeColors.txt");

                    break;
                case 0:

                    repetir = false;
                    break;
                default:
                    System.out.print("Entrada no vàlida, seleccioni una opció.");
            }
        }
        System.out.println("\nAdeu");
    }

    private void menu() {

        System.out.println("                                                 ");
        System.out.println("    Gestió de dades de Colors per nom            ");
        System.out.println("                                                 ");
        System.out.println("        1. Inicialitza fitxer de colors          ");
        System.out.println("        2. Càlcul del color promig               ");
        System.out.println("        3. Array de Color ordenat                ");
        System.out.println("        0. Sortir                                ");
        System.out.println("                                                 ");
    }

    // Métode per poder llegir un caràcter per pantalla
    // S'introdueix el missatge que vols que s'imprimeixi per pantalla com a paràmetre
    private char llegirCaracter(String missatge) {
        char c = ' ';
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(missatge);
            // Llegim un String
            String s = in.readLine();
            // Feim el càsting a char
            char d[] = s.toCharArray();
            c = d[0];

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return c;
    }

    // Mètode per llegir un enter
    private int llegirEnter(String missatge) {
        int x = 0;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print(missatge);
            // Llegim un String
            String s = br.readLine();
            // Feim el càsting a enter
            x = Integer.parseInt(s);

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return x;
    }

}
