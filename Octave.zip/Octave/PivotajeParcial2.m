%Segunda versi�n para el programa de pivotaje parcial de gauss
%La matriz est� inventada.
A=[ 13/10^12 31/10^3 17/10^10 37/10^9 -61/10^10; -23/10^9 13/10^7 -31/10^6 -79/10^8 0; 11/10^4 -13/10^3 0 -1/10^2 -57/10^3; 29/10^3 1/10 -503/10^5 2/10^2 -17/10; 179 -53 277 59 151]
B=[0;3;-5;7;-11]

function y=eliminacion(A,B)
[n n]=size(A);
A=[A';B']';
x=zeros(n,1);
for p=1:n
    for k=[1:p-1,p+1:n];
    m=-A(k,p)/A(p,p);
    A(k,:)=A(k,:)+m*A(p,:)
end
end
x=A(:,n+1)./diag(A)