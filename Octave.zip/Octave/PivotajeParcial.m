%Ejemplo de pivotaje parcial de una matriz en octave




function  Ab  = gaussianapivoteparcial ()
format long
 A = [ 1 3 5 7; 3 9 3 2; 5 1 0 3; 2 7 4 3]
 b= [11;7;2;1]
[n]=size(A); %Tama�o de la matriz A

Ab=[A b]; %Formar la matriz aumentada
Determinante= det(A); %Calcular el determinante de la matriz de coeficientes
NumCondicion=cond(A);%Calcular la magnitud de la matriz de coeficientes

if Determinante == 0
	disp('No se puede continuar, pues se dar� una divisi�n por cero')
endif

if NumCondicion > 1
	disp('La matriz a utilizar no esta bien condicionada, es muy sensible al cambio')
endif

mayor=0;%Declarado un valor inicial considerador como el mayor

for i=1:n-1 %Iniciar ciclo
	for t=i:n %Iniciar ciclo para encontrar el mayor pivote en valor absoluto
		pivote=Ab(t,1); %Candidatos a pivote
			if mayor<abs(pivote) %Verificar si el pivote es m�s grande que el n�mero mayor declarado
			mayor=abs(pivote); %El pivote toma el puesto del n�mero mayor
			filamayor=t; %En que fila se encuentra en pivote mayor
			endif
	endfor
	
	for j=1:n+1 %Ciclo para hacer el cambio de filas
		nube=Ab(i,j); %Guardar en una nube los elementos de la fila indicada
		Ab(i,j)=Ab(filamayor,j); %Sustituir los elementos de esa fila por los elementos de la fila de mayor pivote para que quede en primer lugar
		Ab(filamayor,j)=nube; %Meter los elementos de la fila indicada en el lugar donde estaba la fila de mayor pivote
	endfor
	
	for x=i+1:n %Iniciar ciclo de c�lculo de soluci�n
	Mult=Ab(x,i)/Ab(i,i); %Hallar el multiplicador
		for j=i:n+1
		Ab(x,j)=Ab(x,j)-Mult*Ab(i,j); %Realizar los respectivos cambios en las filas seg�n el m�todo
		endfor
	endfor
endfor

endfunction