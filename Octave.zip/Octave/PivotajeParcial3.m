function  ret  = pivparcial ()
         % ELIMINACI�N GAUSSIANA CON PIVOTEO PARCIAL.
A=[ 13/10^12 31/10^3 17/10^10 37/10^9 -61/10^10; -23/10^9 13/10^7 -31/10^6 -79/10^8 0; 11/10^4 -13/10^3 0 -1/10^2 -57/10^3; 29/10^3 1/10 -503/10^5 2/10^2 -17/10; 179 -53 277 59 151]
b=[0;3;-5;7;-11]
n=size(b);
mataum=[A b]
for i=1:n-1
    mayorpiv=abs(mataum(i,i));
    filamayor=i;
    for f=i+1:n
        if abs(mataum(f,i))>mayorpiv
            mayorpiv=abs(mataum(f,i));
            filamayor=f;
end end
mayorpiv
    if filamayor~=i
     temporal=mataum(filamayor,:);
     mataum(filamayor,:)=mataum(i,:);
     mataum(i,:)=temporal;
end
mataum
    for f=i+1:n
        multiplicador=-mataum(f,i)/mataum(i,i);
        for j=1:n+1
mataum(f,j)=mataum(f,j)+multiplicador*mataum(i,j);
        end
end
mataum
end
endfunction