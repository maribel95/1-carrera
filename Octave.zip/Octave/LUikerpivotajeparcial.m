function [A, P, L] = PivParcialFact (A, P, L, k)
    mayor = abs(A(k,k));
    filaMayor = k;
    for s = k + 1 : rows(A)
        % Se halla el mayor elemento en la columna k de A
        if abs(A(s,k)) > mayor
            mayor = abs(A(s,k));
            filaMayor = s;
        end
    end
    % Se comprueba si el sistema tiene solucion unica
    if mayor == 0
        disp("El sistema no tiene solucion unica");
    else
        if filaMayor != k
            % Se hace intercambio de filas en L, U y P
            aux = A(k,:);
		 	auxP = P(k,:);
			auxL = L(k,:);
			P(k,:) = P(filaMayor,:);
            A(k,:) = A(filaMayor,:);
			L(k,:) = L(filaMayor,:);
			P(filaMayor,:) = auxP;
            A(filaMayor,:) = aux;
			L(filaMayor,:) = auxL;
        end
    end
end