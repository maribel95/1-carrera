%Este programa lo que hace es darte la respuesta directamente

U=[ -1 1 1;2 -3 -3; -5 2 4]
b=[1; -6; 5];


function [x] = susreg(U,b)
  n=length(b);
  x=zeros(n,1);
  for k=n:-1:1
    x(k)=b(k)/U(k,k);
    for i=1:k-1
      b(i)=b(i)-x(k)*U(i,k);
    endfor
  endfor
endfunction
