%Ejercicio 1
%Halle la suma de los elementos de una matriz cuadrada
A=[1 2 3; 8 5 0; 9 4 7]
n=size(A)(1); %Porque la matriz es de 3x3
suma=0; %Contador que inicializamos en cero
%El punto y coma es para que no se muestre por pantalla
for f=1:n %Primero recorremos filas y luego columnas
  for c=1:n
    suma= suma + A(f,c);
  end
end
suma

%%Ejercicio 2
%Cambiar los elementos pares de una matriz cuadrada a 0
for f=1:n 
  for c=1:n
    x = A(f,c);
    if mod(x,2) == 0
      A(f,c)=0;
    end
  end
end
A