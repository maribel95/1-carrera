function [] = factLUElimGaussSimple (A,b)
	A = [11 -3 -2; 5 -2 -8; 4 -7 2]
		% Se halla L y U
		L = eye(rows(A));
		for k = 1 : rows(A) - 1
			for i = k + 1 : rows(A)
				% Se halla el multiplicador Mij
				M = A(i,k) / A(k,k);
				% Se calcula la nueva fila i
				A(i,:) = A(i,:) - M * A(k,:);
				% Se le pone el valor de Mij a L
				if i > k
					L(i,k) = M;
				end
			end
		%Se muestran las matrices resultantes L y U
		U = A
		L 
	  end
end