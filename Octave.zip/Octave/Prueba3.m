A= zeros(4)
valor= 3

for x = 1:4
  for y = x:4
    A(x,y) = valor
  endfor
endfor

disp(A)
