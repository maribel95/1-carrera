%Pr�ctica clase de pivotaje parcial de una matriz

A=[ 13/10^12 31/10^3 17/10^10 37/10^9 -61/10^10; -23/10^9 13/10^7 -31/10^6 -79/10^8 0; 11/10^4 -13/10^3 0 -1/10^2 -57/10^3; 29/10^3 1/10 -503/10^5 2/10^2 -17/10; 179 -53 277 59 151]
b=[0;3;-5;7;-11]

function [A,b]=Gauss(A,b) 
  n=length(b);
for k=1:n-1
  
for i=k+1:n m=A(i,k)/A(k,k); 
  A(i,k)=0;
for j=k+1:n
A(i,j)=A(i,j)-m*A(k,j); 
endfor
b(i)=b(i)-m*b(k);

endfor 
endfor 
endfunction